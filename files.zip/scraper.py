"""
scraper.py — YouTube channel discovery and data extraction
"""

import logging
import re
import time
from dataclasses import dataclass, field
from typing import List, Optional

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout

from config import (
    CHANNEL_VISIT_WAIT,
    MAX_RETRIES,
    MAX_SCROLL_ATTEMPTS,
    PAGE_LOAD_WAIT,
    SCROLL_PAUSE,
    YOUTUBE_BASE,
    YOUTUBE_SEARCH,
)

logger = logging.getLogger("yt_discovery.scraper")


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class Channel:
    name: str = ""
    url: str = ""
    subscriber_count: int = 0
    subscriber_raw: str = ""
    description: str = ""
    keywords_matched: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "Channel Name": self.name,
            "Channel URL": self.url,
            "Subscribers": self.subscriber_count,
            "Subscribers (Raw)": self.subscriber_raw,
            "Description": self.description,
            "Keywords Matched": ", ".join(self.keywords_matched),
        }


# ── Main scraper ──────────────────────────────────────────────────────────────

class YouTubeScraper:
    def __init__(self, page: Page):
        self.page = page

    # ── Public API ─────────────────────────────────────────────────────────────

    def discover_channels(self, category: str, num_channels: int) -> List[str]:
        """
        Search YouTube for *category* (filtered to Channels) and return
        a deduplicated list of channel URLs.
        """
        query = category.strip().replace(" ", "+")
        search_url = YOUTUBE_SEARCH.format(query=query)
        logger.info("Searching YouTube for category: '%s'", category)
        logger.debug("Search URL: %s", search_url)

        # FIX #5: use domcontentloaded instead of networkidle — YouTube never
        # reaches networkidle due to background XHR polling, causing timeouts.
        self.page.goto(search_url, wait_until="domcontentloaded")
        time.sleep(PAGE_LOAD_WAIT + 1)  # extra second for JS to render results

        channel_urls: List[str] = []
        attempts = 0

        while len(channel_urls) < num_channels and attempts < MAX_SCROLL_ATTEMPTS:
            urls = self._extract_channel_links_from_results()
            for url in urls:
                if url not in channel_urls:
                    channel_urls.append(url)

            logger.info(
                "  Found %d unique channel URLs so far (target: %d)",
                len(channel_urls),
                num_channels,
            )

            if len(channel_urls) >= num_channels:
                break

            # FIX #6: if no URLs came back yet, wait for lazy-load before scrolling
            if not urls:
                logger.debug("No URLs yet — waiting for lazy-load …")
                time.sleep(1)

            self._scroll_down()
            attempts += 1

        logger.info("Discovery complete — %d channels found", len(channel_urls))
        return channel_urls[:num_channels]

    def get_channel_info(self, channel_url: str) -> Optional["Channel"]:
        """
        Visit a channel page and extract metadata.
        Returns None if scraping fails after retries.
        """
        # FIX #3: YouTube removed the /about tab in 2023. We visit the channel
        # home page and fall back to /about only as a secondary attempt, since
        # some older-style /channel/UC… URLs still show an about tab.
        urls_to_try = [
            channel_url.rstrip("/"),              # home page (current YouTube)
            channel_url.rstrip("/") + "/about",  # legacy fallback
        ]

        for attempt in range(1, MAX_RETRIES + 1):
            target_url = urls_to_try[(attempt - 1) % len(urls_to_try)]
            try:
                logger.debug("Visiting %s (attempt %d)", target_url, attempt)
                self.page.goto(target_url, wait_until="domcontentloaded")
                time.sleep(CHANNEL_VISIT_WAIT)
                ch = self._parse_channel_page(channel_url)
                # Consider it a success even if name is empty — caller decides
                return ch
            except PlaywrightTimeout as exc:
                logger.warning(
                    "Timeout on %s (attempt %d/%d): %s",
                    target_url,
                    attempt,
                    MAX_RETRIES,
                    exc,
                )
                time.sleep(2)
            except Exception as exc:  # noqa: BLE001
                logger.error("Error fetching %s: %s", target_url, exc)
                break

        return None

    # ── Private helpers ────────────────────────────────────────────────────────

    def _extract_channel_links_from_results(self) -> List[str]:
        """Parse current search-results page for channel hrefs."""
        links = []
        try:
            self.page.wait_for_selector(
                'ytd-channel-renderer, a[href*="/@"], a[href*="/channel/"]',
                timeout=10_000,
            )
        except PlaywrightTimeout:
            logger.warning("No channel cards found on results page.")
            return links

        anchors = self.page.query_selector_all(
            'ytd-channel-renderer a.channel-link, '
            'ytd-channel-renderer a[href*="/@"], '
            'ytd-channel-renderer a[href*="/channel/"]'
        )

        seen = set()
        for anchor in anchors:
            href = anchor.get_attribute("href") or ""
            if not href:
                continue
            full = href if href.startswith("http") else YOUTUBE_BASE + href
            full = full.split("?")[0].rstrip("/")
            if full not in seen and ("/channel/" in full or "/@" in full):
                seen.add(full)
                links.append(full)

        logger.debug("Extracted %d links from page", len(links))
        return links

    def _scroll_down(self) -> None:
        """Scroll to the bottom of the page to trigger infinite-scroll loading."""
        logger.debug("Scrolling for more results …")
        self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        time.sleep(SCROLL_PAUSE)

    def _parse_channel_page(self, channel_url: str) -> "Channel":
        """Extract channel metadata from the current page."""
        channel = Channel(url=channel_url)

        # ── Channel name ───────────────────────────────────────────────────────
        # FIX #1: Only pass attr="content" for <meta> tags. Regular DOM elements
        # need inner_text(); passing attr="content" on them always returns "".
        channel.name = self._extract_text_first(
            [
                # Modern YouTube: handle-based pages
                "yt-formatted-string.ytd-channel-name",
                "#channel-name yt-formatted-string",
                "#channel-header-container #text",
                "#inner-header-container #text",
                # Visually-hidden but reliable heading
                "h1.ytd-channel-name",
                "#channel-header h1",
                # Any prominent h1 on the page
                "h1",
            ]
        ) or self._extract_text_first(
            # Meta fallback (attr="content" is correct here)
            ['meta[property="og:title"]', 'meta[name="title"]'],
            attr="content",
        )

        # ── Subscriber count ───────────────────────────────────────────────────
        sub_raw = self._extract_text_first(
            [
                "#subscriber-count",
                "yt-formatted-string#subscriber-count",
                "#metadata-container #subscriber-count",
                'span[id="subscribers"]',
                # Channel home page shows subscribers inside the header
                "#channel-header-container #subscriber-count",
                "yt-content-metadata-view-model span",
            ]
        )
        channel.subscriber_raw = sub_raw
        channel.subscriber_count = _parse_subscriber_count(sub_raw)

        # ── Description ────────────────────────────────────────────────────────
        # FIX #2: Same as #1 — only use attr="content" for <meta> elements.
        channel.description = self._extract_text_first(
            [
                "#description-container #description",
                "yt-formatted-string#description",
                "#description",
                # Channel home page
                "#channel-description-container",
                "ytd-channel-about-metadata-renderer #description",
                "#contentWrapper #description",
            ]
        ) or self._extract_text_first(
            # Meta fallback
            ['meta[name="description"]', 'meta[property="og:description"]'],
            attr="content",
        )

        logger.debug(
            "Parsed: name='%s' | subs=%d | desc_len=%d",
            channel.name,
            channel.subscriber_count,
            len(channel.description),
        )
        return channel

    def _extract_text_first(
        self, selectors: List[str], attr: Optional[str] = None
    ) -> str:
        """
        Try each selector in order; return the first non-empty text or
        attribute value found. Returns empty string on total failure.
        """
        for sel in selectors:
            try:
                el = self.page.query_selector(sel)
                if el is None:
                    continue
                if attr:
                    val = el.get_attribute(attr) or ""
                else:
                    val = el.inner_text().strip()
                if val:
                    return val
            except Exception:  # noqa: BLE001
                continue
        return ""


# ── Utility ───────────────────────────────────────────────────────────────────

def _parse_subscriber_count(raw: str) -> int:
    """
    Convert YouTube subscriber strings to integers.

    Examples:
        '1.23M subscribers' → 1_230_000
        '45.6K subscribers' → 45_600
        '999 subscribers'   → 999
        '1,234,567'         → 1_234_567
    """
    if not raw:
        return 0

    raw = raw.strip().upper()

    # FIX #4: more precise regex — matches optional decimal and known suffixes
    match = re.search(r"([\d,]+\.?\d*)\s*([KMB]?)", raw)
    if not match:
        return 0

    num_str = match.group(1).replace(",", "")
    suffix = match.group(2)

    try:
        num = float(num_str)
    except ValueError:
        return 0

    multipliers = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}
    return int(num * multipliers.get(suffix, 1))
