"""
auth.py — Google / YouTube login via Playwright
"""

import logging
import time

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout

from config import YOUTUBE_LOGIN, PAGE_LOAD_WAIT

logger = logging.getLogger("yt_discovery.auth")


class LoginError(Exception):
    """Raised when login fails."""


def login_youtube(page: Page, gmail: str, password: str) -> None:
    """
    Log into YouTube using Google credentials.

    Steps:
      1. Navigate to the Google sign-in page.
      2. Enter e-mail and click Next.
      3. Enter password and click Next.
      4. Verify we land on YouTube.

    Notes:
      - If 2-FA is required the browser stays open so the user can complete
        it manually within 30 seconds.
      - Captcha / unusual-activity pages are flagged with a clear message.
    """
    logger.info("Navigating to Google sign-in page …")
    page.goto(YOUTUBE_LOGIN, wait_until="domcontentloaded")
    time.sleep(PAGE_LOAD_WAIT)

    _fill_email(page, gmail)
    _fill_password(page, password)
    _verify_login(page)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _fill_email(page: Page, gmail: str) -> None:
    logger.debug("Entering e-mail …")
    selectors = [
        'input[type="email"]',
        "#identifierId",
    ]
    _wait_and_fill(page, selectors, gmail, label="e-mail field")
    _click_next(page)
    time.sleep(PAGE_LOAD_WAIT)


def _fill_password(page: Page, password: str) -> None:
    logger.debug("Entering password …")
    selectors = [
        'input[type="password"]',
        'input[name="Passwd"]',
        # Google sometimes uses this name attribute
        'input[name="password"]',
    ]
    _wait_and_fill(page, selectors, password, label="password field")
    _click_next(page)
    # Give extra time for post-login redirect / 2-FA prompt
    time.sleep(PAGE_LOAD_WAIT + 2)


def _verify_login(page: Page) -> None:
    """
    Check whether login succeeded.
    Waits up to 30 s to allow manual 2-FA completion.
    """
    logger.debug("Verifying login …")
    try:
        # Wait up to 30 s — covers manual 2-FA entry
        page.wait_for_url("*youtube.com*", timeout=30_000)
        logger.info("✅  Login successful — on YouTube")
        return
    except PlaywrightTimeout:
        pass

    current = page.url
    if "myaccount.google.com" in current or "youtube.com" in current:
        logger.info("✅  Logged in (landed on: %s)", current)
    elif "accounts.google.com/signin/challenge" in current:
        raise LoginError(
            "Google is asking for a security challenge (2-FA / captcha). "
            "Set HEADLESS = False and complete the challenge manually, "
            "then re-run."
        )
    elif "signin" in current or "accounts.google.com" in current:
        raise LoginError(
            "Login failed — still on sign-in page. "
            "Check your credentials or complete any 2-FA manually."
        )
    else:
        logger.warning("Login status unclear — URL: %s", current)


def _wait_and_fill(page: Page, selectors: list, value: str, label: str) -> None:
    """Try multiple selectors until one is fillable."""
    for selector in selectors:
        try:
            page.wait_for_selector(selector, state="visible", timeout=8_000)
            page.fill(selector, value)
            logger.debug("Filled %s via selector '%s'", label, selector)
            return
        except PlaywrightTimeout:
            continue
    raise LoginError(f"Could not locate {label}. Selectors tried: {selectors}")


def _click_next(page: Page) -> None:
    """Click the 'Next' button on Google sign-in forms."""
    next_selectors = [
        "#identifierNext button",
        "#identifierNext",
        "#passwordNext button",
        "#passwordNext",
        'button:has-text("Next")',
        '[jsname="LgbsSe"]',
    ]
    for sel in next_selectors:
        try:
            page.wait_for_selector(sel, state="visible", timeout=5_000)
            page.click(sel)
            return
        except PlaywrightTimeout:
            continue
    raise LoginError("Could not find 'Next' button on sign-in page.")
