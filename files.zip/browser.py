"""
browser.py — Playwright browser lifecycle management
"""

import logging
from contextlib import contextmanager
from typing import Generator

from playwright.sync_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    sync_playwright,
)

from config import (
    BROWSER_TIMEOUT,
    HEADLESS,
    NAVIGATION_TIMEOUT,
    SLOW_MO,
)

logger = logging.getLogger("yt_discovery.browser")


def create_browser(playwright: Playwright) -> Browser:
    """Launch a Chromium browser with anti-detection tweaks."""
    logger.debug("Launching Chromium (headless=%s, slow_mo=%s)", HEADLESS, SLOW_MO)
    browser = playwright.chromium.launch(
        headless=HEADLESS,
        slow_mo=SLOW_MO,
        args=[
            "--disable-blink-features=AutomationControlled",
            "--start-maximized",
        ],
    )
    return browser


def create_context(browser: Browser) -> BrowserContext:
    """Create a browser context that mimics a real Chrome user."""
    context = browser.new_context(
        viewport={"width": 1366, "height": 768},
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        locale="en-US",
        timezone_id="America/New_York",
    )
    context.set_default_timeout(BROWSER_TIMEOUT)
    context.set_default_navigation_timeout(NAVIGATION_TIMEOUT)
    return context


def create_page(context: BrowserContext) -> Page:
    """Open a new page and hide webdriver signals."""
    page = context.new_page()
    # Mask navigator.webdriver flag
    page.add_init_script(
        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    )
    return page


@contextmanager
def managed_browser() -> Generator[Page, None, None]:
    """
    Context manager that yields a configured Playwright Page.
    Handles teardown automatically.
    """
    with sync_playwright() as playwright:
        browser = create_browser(playwright)
        context = create_context(browser)
        page = create_page(context)
        try:
            logger.info("Browser ready")
            yield page
        finally:
            logger.info("Closing browser")
            context.close()
            browser.close()
