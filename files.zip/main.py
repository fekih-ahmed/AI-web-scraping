import getpass
import sys
import time
from typing import List

from auth import LoginError, login_youtube
from browser import managed_browser
from config import UserConfig
from exporter import export_csv, export_excel
from filters import filter_channels
from logger import setup_logger
from scraper import Channel, YouTubeScraper

logger = setup_logger("yt_discovery")


# ── CLI prompts ────────────────────────────────────────────────────────────────

def _prompt(msg: str, default: str = "") -> str:
    val = input(msg).strip()
    return val if val else default


def _prompt_int(msg: str, default: int = 0) -> int:
    while True:
        raw = input(msg).strip()
        if not raw:
            return default
        try:
            return int(raw)
        except ValueError:
            print("  ⚠  Please enter a whole number.")


def collect_user_input() -> UserConfig:
    """Interactively collect all configuration from the user."""
    print("\n" + "=" * 60)
    print("   🎬  YouTube Channel Discovery Tool")
    print("=" * 60 + "\n")

    cfg = UserConfig()

    # Credentials
    cfg.gmail = _prompt("📧  Gmail address : ")
    if not cfg.gmail:
        print("Gmail address is required. Exiting.")
        sys.exit(1)

    cfg.password = getpass.getpass("🔑  Gmail password : ")
    if not cfg.password:
        print("Password is required. Exiting.")
        sys.exit(1)

    # Category
    print("\nExamples: Gaming, Programming, AI, Football, Finance, Music, Travel")
    cfg.category = _prompt("🔍  YouTube category : ")
    if not cfg.category:
        print("Category is required. Exiting.")
        sys.exit(1)

    # Numeric params
    cfg.num_channels = _prompt_int(
        "📊  Number of channels to collect [20] : ", default=20
    )
    cfg.min_subscribers = _prompt_int(
        "👥  Minimum subscriber count        [0] : ", default=0
    )

    # Keywords
    raw_kw = _prompt(
        "🔑  Required keywords (comma-separated, leave blank for none) : "
    )
    cfg.keywords = [kw.strip() for kw in raw_kw.split(",") if kw.strip()]

    # Summary
    print("\n" + "-" * 60)
    print(f"  Category      : {cfg.category}")
    print(f"  Channels      : {cfg.num_channels}")
    print(f"  Min subs      : {cfg.min_subscribers:,}")
    print(f"  Keywords      : {cfg.keywords or 'None'}")
    print("-" * 60 + "\n")

    return cfg


# ── Orchestrator ───────────────────────────────────────────────────────────────

def run(cfg: UserConfig) -> None:
    start = time.time()

    with managed_browser() as page:

        # 1. Login
        logger.info("Step 1/5 — Logging in as %s", cfg.gmail)
        try:
            login_youtube(page, cfg.gmail, cfg.password)
        except LoginError as exc:
            logger.critical("Login failed: %s", exc)
            print(f"\n❌  Login failed: {exc}")
            return

        # 2. Discover channel URLs
        logger.info("Step 2/5 — Discovering channels for '%s'", cfg.category)
        scraper = YouTubeScraper(page)
        # Fetch 2× requested count to have buffer after filtering
        channel_urls: List[str] = scraper.discover_channels(
            cfg.category, cfg.num_channels * 2
        )
        print(f"  📡  Found {len(channel_urls)} channel URLs")

        if not channel_urls:
            print("\n❌  No channel URLs found. Try a different category or check your internet connection.")
            return

        # 3. Extract channel data
        logger.info("Step 3/5 — Extracting channel details")
        channels: List[Channel] = []
        for idx, url in enumerate(channel_urls, start=1):
            print(f"  [{idx}/{len(channel_urls)}] Fetching: {url[:60]:<60}", end="\r")
            ch = scraper.get_channel_info(url)
            if ch and ch.name:
                channels.append(ch)
            elif ch:
                # Channel page loaded but name was empty — still keep it with URL as fallback
                ch.name = url.split("/")[-1]  # use handle as name fallback
                channels.append(ch)
                logger.debug("Used URL handle as name fallback for %s", url)

        print()  # newline after \r progress

        logger.info(
            "Successfully extracted %d / %d channels",
            len(channels),
            len(channel_urls),
        )

        if not channels:
            print("\n❌  Could not extract data from any channel. YouTube may have changed its page structure.")
            return

        # 4. Filter
        logger.info("Step 4/5 — Filtering channels")
        filtered = filter_channels(channels, cfg.min_subscribers, cfg.keywords)
        filtered = filtered[: cfg.num_channels]

        if not filtered:
            print("\n⚠  No channels matched your criteria after filtering.")
            print(f"   Tip: {len(channels)} channels were found but none passed the filters.")
            print("   Try lowering the minimum subscriber count or removing keywords.")
            logger.warning("No channels passed filters.")
            return

        print(f"\n✅  {len(filtered)} channels passed filters")
        _print_summary_table(filtered)

        # 5. Export
        logger.info("Step 5/5 — Exporting results")
        csv_path = export_csv(filtered)
        xlsx_path = export_excel(filtered)

        elapsed = time.time() - start
        print("\n" + "=" * 60)
        print(f"  💾  CSV   → {csv_path}")
        print(f"  💾  Excel → {xlsx_path}")
        print(f"  ⏱   Completed in {elapsed:.1f}s")
        print("=" * 60 + "\n")


# ── Pretty table ───────────────────────────────────────────────────────────────

def _print_summary_table(channels: List[Channel]) -> None:
    col_w = [40, 15, 30]
    header = (
        f"  {'Channel Name':<{col_w[0]}} {'Subscribers':>{col_w[1]}}  "
        f"{'URL':<{col_w[2]}}"
    )
    print("\n" + header)
    print("  " + "-" * (sum(col_w) + 4))
    for ch in channels:
        name = ch.name[: col_w[0] - 1] if len(ch.name) > col_w[0] else ch.name
        subs = f"{ch.subscriber_count:,}" if ch.subscriber_count else "N/A"
        url = ch.url[: col_w[2] - 1] if len(ch.url) > col_w[2] else ch.url
        print(f"  {name:<{col_w[0]}} {subs:>{col_w[1]}}  {url}")


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    try:
        user_cfg = collect_user_input()
        run(user_cfg)
    except KeyboardInterrupt:
        print("\n\n⚠  Interrupted by user. Exiting.")
        sys.exit(0)
