"""
exporter.py — CSV and Excel export for discovered channels
"""

import csv
import logging
import os
from datetime import datetime
from typing import List

from scraper import Channel
from config import OUTPUT_DIR, CSV_FILENAME, EXCEL_FILENAME

logger = logging.getLogger("yt_discovery.exporter")

# Optional Excel dependency
try:
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    logger.warning("openpyxl not installed — Excel export disabled.")


def _timestamped(filename: str) -> str:
    """Prefix a filename with a YYYYMMDD_HHMMSS timestamp."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base, ext = os.path.splitext(filename)
    return f"{base}_{stamp}{ext}"


def export_csv(channels: List[Channel]) -> str:
    """
    Write channels to a CSV file inside OUTPUT_DIR.
    Returns the absolute path to the created file.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    path = os.path.join(OUTPUT_DIR, _timestamped(CSV_FILENAME))

    if not channels:
        logger.warning("No channels to export (CSV).")
        return path

    fieldnames = list(channels[0].to_dict().keys())
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for ch in channels:
            writer.writerow(ch.to_dict())

    logger.info("CSV exported → %s (%d rows)", path, len(channels))
    return path


def export_excel(channels: List[Channel]) -> str:
    """
    Write channels to a styled Excel file inside OUTPUT_DIR.
    Returns the absolute path to the created file.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    path = os.path.join(OUTPUT_DIR, _timestamped(EXCEL_FILENAME))

    if not EXCEL_AVAILABLE:
        logger.error("Cannot export Excel — openpyxl missing.")
        return path

    if not channels:
        logger.warning("No channels to export (Excel).")
        return path

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "YouTube Channels"

    # ── Header row ─────────────────────────────────────────────────────────────
    headers = list(channels[0].to_dict().keys())
    header_fill = PatternFill("solid", fgColor="FF0000")        # YouTube red
    header_font = Font(bold=True, color="FFFFFF", size=11)

    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    ws.row_dimensions[1].height = 22

    # ── Data rows ──────────────────────────────────────────────────────────────
    alt_fill = PatternFill("solid", fgColor="FFF0F0")           # Light pink

    for row_idx, ch in enumerate(channels, start=2):
        data = ch.to_dict()
        for col_idx, key in enumerate(headers, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=data[key])
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            if row_idx % 2 == 0:
                cell.fill = alt_fill

    # ── Column widths ──────────────────────────────────────────────────────────
    column_widths = {
        "Channel Name": 30,
        "Channel URL": 45,
        "Subscribers": 15,
        "Subscribers (Raw)": 18,
        "Description": 60,
        "Keywords Matched": 30,
    }
    for col_idx, header in enumerate(headers, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = column_widths.get(
            header, 20
        )

    # ── Freeze header ──────────────────────────────────────────────────────────
    ws.freeze_panes = "A2"

    wb.save(path)
    logger.info("Excel exported → %s (%d rows)", path, len(channels))
    return path
