"""
filters.py — Channel filtering logic
"""

import logging
from typing import List

from scraper import Channel

logger = logging.getLogger("yt_discovery.filters")


def filter_channels(
    channels: List[Channel],
    min_subscribers: int,
    keywords: List[str],
) -> List[Channel]:
    """
    Apply user-defined filters to a list of Channel objects.

    Filters applied (in order):
      1. Minimum subscriber count.
      2. Required keywords — channel name OR description must contain
         at least one keyword (case-insensitive).
         If no keywords are provided this filter is skipped.

    Matched keywords are stored in ``channel.keywords_matched`` for reporting.
    """
    logger.info(
        "Filtering %d channels | min_subs=%d | keywords=%s",
        len(channels),
        min_subscribers,
        keywords,
    )

    result: List[Channel] = []
    kw_lower = [kw.strip().lower() for kw in keywords if kw.strip()]

    for ch in channels:
        # ── 1. Subscriber filter ───────────────────────────────────────────────
        if ch.subscriber_count < min_subscribers:
            logger.debug(
                "FILTERED (subs) → '%s' (%d < %d)",
                ch.name,
                ch.subscriber_count,
                min_subscribers,
            )
            continue

        # ── 2. Keyword filter ──────────────────────────────────────────────────
        if kw_lower:
            haystack = (ch.name + " " + ch.description).lower()
            matched = [kw for kw in kw_lower if kw in haystack]
            if not matched:
                logger.debug(
                    "FILTERED (keywords) → '%s'",
                    ch.name,
                )
                continue
            ch.keywords_matched = matched

        result.append(ch)
        logger.debug("PASSED → '%s' (%d subs)", ch.name, ch.subscriber_count)

    logger.info(
        "Filtering complete — %d/%d channels passed",
        len(result),
        len(channels),
    )
    return result
