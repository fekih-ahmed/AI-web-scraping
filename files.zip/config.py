"""
config.py — Central configuration for YouTube Channel Discovery
"""

import os
from dataclasses import dataclass, field
from typing import List

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
LOG_DIR = os.path.join(BASE_DIR, "logs")

# ── Browser ───────────────────────────────────────────────────────────────────
HEADLESS = False                  # Keep False — reduces bot-detection risk
SLOW_MO = 80                      # Slightly higher ms helps avoid detection
BROWSER_TIMEOUT = 30_000          # Default element timeout in ms
NAVIGATION_TIMEOUT = 60_000       # Page navigation timeout in ms

# ── YouTube URLs ──────────────────────────────────────────────────────────────
YOUTUBE_BASE = "https://www.youtube.com"
YOUTUBE_LOGIN = "https://accounts.google.com/signin/v2/identifier?service=youtube"
# sp=EgIQAg%3D%3D → filter: Channels only
YOUTUBE_SEARCH = "https://www.youtube.com/results?search_query={query}&sp=EgIQAg%3D%3D"

# ── Delays (seconds) ──────────────────────────────────────────────────────────
PAGE_LOAD_WAIT = 3
SCROLL_PAUSE = 2                  # Increased from 1.5 — gives YouTube time to load cards
CHANNEL_VISIT_WAIT = 3            # Increased from 2 — channel pages are JS-heavy

# ── Retry / robustness ────────────────────────────────────────────────────────
MAX_RETRIES = 3
MAX_SCROLL_ATTEMPTS = 15          # Increased from 10 to collect more results

# ── Export filenames ──────────────────────────────────────────────────────────
CSV_FILENAME = "youtube_channels.csv"
EXCEL_FILENAME = "youtube_channels.xlsx"

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_LEVEL = "DEBUG"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


@dataclass
class UserConfig:
    """Runtime configuration filled from terminal prompts."""
    gmail: str = ""
    password: str = ""
    category: str = ""
    num_channels: int = 20
    min_subscribers: int = 0
    keywords: List[str] = field(default_factory=list)
